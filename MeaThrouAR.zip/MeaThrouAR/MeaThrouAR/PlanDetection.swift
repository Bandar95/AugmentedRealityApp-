//
//  3Dshapes.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 14/05/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import AVFoundation
import Vision


class PlanDetection: UIViewController, ARSCNViewDelegate {
    
    @IBOutlet weak var Debug: UITextView!
    @IBOutlet weak var prSave: UIButton!
    @IBOutlet weak var wall: UIButton!
    @IBOutlet weak var line: UIButton!
    @IBOutlet weak var area: UIButton!
    @IBOutlet weak var Text1: UILabel!
    var lineButtonCenter : CGPoint!// to take the cube button center
    var areaBottunCenter : CGPoint!// to take the area button center
    var saveButtonCenter : CGPoint!
    @IBOutlet var sceneView: ARSCNView!
    
    
    let configuration = ARWorldTrackingConfiguration()
    var sound:AVAudioPlayer?
    var sound2:AVAudioPlayer?
    
    
    let dispatchQueueML = DispatchQueue(label: "com.hw.dispatchqueueml") // A Serial Queue
    var visionRequests = [VNRequest]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // identify the place of buttons
        lineButtonCenter=line.center
        areaBottunCenter=area.center
        saveButtonCenter=prSave.center
        
        line.center = wall.center
        area.center = wall.center
        prSave.center=wall.center
        
        
        sceneView.delegate = self
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
       
        let scene = SCNScene() // SCNScene(named: "art.scnassets/ship.scn")!
        
        // Set the scene to the view
        sceneView.scene = scene
        
        guard let selectedModel = try? VNCoreMLModel(for: DetectHand().model) else {
            fatalError("Could not load model. Ensure model has been drag and dropped (copied) to XCode Project. Also ensure the model is part of a target (see: https://stackoverflow.com/questions/45884085/model-is-not-part-of-any-target-add-the-model-to-a-target-to-enable-generation ")
        }
        
        // Set up Vision-CoreML Request
        let classificationRequest = VNCoreMLRequest(model: selectedModel, completionHandler: classificationCompleteHandler)
        classificationRequest.imageCropAndScaleOption = VNImageCropAndScaleOption.centerCrop // Crop from centre of images and scale to appropriate size.
        visionRequests = [classificationRequest]
        
        loopCoreMLUpdate()
        

    }
    
    
    
    
    
    
    
    
    
    @IBAction func cubeClicked(_ sender: UIButton) {
        if wall.currentImage == UIImage (named: "wall_on")! {
            UIView.animate(withDuration: 0.3, animations: {//the animation of buttons
                //to make buttons are visible
                self.line.alpha=1
                self.area.alpha=1
                self.prSave.alpha=1
                // to open the menu
                self.line.center = self.lineButtonCenter
                self.area.center = self.areaBottunCenter
                self.prSave.center=self.saveButtonCenter
            })
        }else {
            UIView.animate(withDuration: 0.3, animations: {
                self.line.alpha=0
                self.area.alpha=0
                self.prSave.alpha=0
                
                self.line.center = self.wall.center
                self.area.center = self.wall.center
                self.prSave.center=self.wall.center
            })
            
        }
        tuggButton(button: sender, onImage:UIImage(named: "wall_on")!, offImage: UIImage(named: "wall_off")!)
        
    }
    func tuggButton(button : UIButton, onImage: UIImage, offImage: UIImage){
        if button.currentImage==offImage{
            button.setImage(onImage, for: .normal)
        }else{
            button.setImage(offImage, for: .normal)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        // Create a session configuration
        
      configuration.planeDetection = [.horizontal, .vertical]
        // Run the view's session
       sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    func setText1(text: String) {
        Text1.text = text
    }
    
    func renderer1(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            // Do any desired updates to SceneKit here.
        }
    }
    
    
    func loopCoreMLUpdate() {
        // Continuously run CoreML whenever it's ready. (Preventing 'hiccups' in Frame Rate)
        dispatchQueueML.async {
            // 1. Run Update.
            self.updateCoreML()
            // 2. Loop this function.
            self.loopCoreMLUpdate()
        }
    }
    
    
    func updateCoreML() {
        // Get Camera Image as RGB
        let pixbuff : CVPixelBuffer? = (sceneView.session.currentFrame?.capturedImage)
        if pixbuff == nil { return }
        let ciImage = CIImage(cvPixelBuffer: pixbuff!)
        
        // Prepare CoreML/Vision Request
        let imageRequestHandler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        // Run Vision Image Request
        do {
            try imageRequestHandler.perform(self.visionRequests)
        } catch {
            print(error)
        }
    }
    
    
    
    func classificationCompleteHandler(request: VNRequest, error: Error?) {
        // Catch Errors
        if error != nil {
            print("Error: " + (error?.localizedDescription)!)
            return
        }
        guard let observations = request.results else {
            print("No results")
            return
        }
        
        // Get Classifications
        let classifications = observations[0...1] // top 2 results
            .compactMap({ $0 as? VNClassificationObservation })
            .map({ "\($0.identifier) \(String(format:" : %.2f", $0.confidence))" })
            .joined(separator: "\n")
        
        // Render Classifications
        DispatchQueue.main.async {
            // Print Classifications
            // print(classifications)
            // print("-------------")
            
            // Display Debug Text on screen
            
            self.Debug.text = "TOP 2 PROBABILITIES: \n" + classifications
            
            // Display Top Symbol
            // var symbol = ""
            let topPrediction = classifications.components(separatedBy: "\n")[0]
            let topPredictionName = topPrediction.components(separatedBy: ":")[0].trimmingCharacters(in: .whitespaces)
            // Only display a prediction if confidence is above 1%
            let topPredictionScore:Float? = Float(topPrediction.components(separatedBy: ":")[1].trimmingCharacters(in: .whitespaces))
            if (topPredictionScore != nil && topPredictionScore! > 0.01) {
                
                if (topPredictionName == "NOHand") {
                    print("Nnhand")
                }
                
                if (topPredictionName == "OpenHand") {
                    print("OpenHand")
                    self.Reset()
                   
                    
                }
            }
            
            //  self.textOverlay.text = symbol
            
        }
    }
    
    
    override var prefersStatusBarHidden : Bool { return true }
    
    
    //   ----------------------------------------------------------------
    
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        let plane = SCNPlane(width: CGFloat(planeAnchor.extent.x), height:
            CGFloat(planeAnchor.extent.z))
        let planeNode = SCNNode(geometry: plane)
        planeNode.simdPosition = float3(planeAnchor.center.x, 0,
                                        planeAnchor.center.z)
        planeNode.eulerAngles.x = -.pi / 2
        node.addChildNode(planeNode)
        let distance = distanceFromCamera(x: planeAnchor.center.x, y: 0, z: planeAnchor.center.z)
        let formatted = String(format: "Distance: %.2f", distance) // for checking
        print(formatted)
        
       
        
        if distance < 0.20 {
          
            self.setText1(text:String(format: "Distance is: %.2f", distance*100))
            playSound2()
            playSound()
            
       //     sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
            
        } else {
          //  self.setText1(text: String("the Distance is : %.2f\(distance)"))
             self.setText1(text:String(format: "Distance is: %.2f", distance*100))
            sound?.stop()
            sound2?.stop()
        }
        
    }
    
    private func distanceFromCamera(x: Float, y:Float, z:Float) -> Float {
        let cameraPosition =  self.sceneView.session.currentFrame!.camera.transform.columns.3
        print("Camera: \(cameraPosition)")
        let vector = SCNVector3Make(cameraPosition.x - x, cameraPosition.y - y, cameraPosition.z - z)
        
        // Scene units map to meters in ARKit.
        return sqrtf(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z)
    }
    
    
    
    func playSound(){
        
        guard let URL = Bundle.main.url(forResource: "Becare", withExtension: "mp3")
            else{return}
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            sound = try AVAudioPlayer(contentsOf: URL, fileTypeHint: AVFileType.mp3.rawValue)
            guard let sound = sound else {return}
            sound.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    func playSound2(){
        
        guard let URL1 = Bundle.main.url(forResource: "boob", withExtension: "mp3")
            else{return}
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            sound2 = try AVAudioPlayer(contentsOf: URL1, fileTypeHint: AVFileType.mp3.rawValue)
            guard let sound = sound2 else {return}
            sound.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    /*
    @IBAction func Reset(_ sender: UIButton) {
        
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])

        
    }
    
    */
    
func Reset() {
        
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    
    }
    
    @IBAction func FlashLight(_ sender: Any) {
        
        var isTourch = false
        
        guard let device = AVCaptureDevice.default(for: AVMediaType.video) else { return }
        
        if device.hasTorch {
            isTourch = !isTourch
            
            do {
                
                try device.lockForConfiguration()
                
                if isTourch == true {
                    
                    device.torchMode = .on
                    
                }else  {
                    
                    device.torchMode = .off
            //     isTourch = true
                }
                
                device.unlockForConfiguration()
            } catch {
                
                print("Torch is not working.")
            }
            
        } else {
            
            print("Torch not compatible with device.")
            
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

