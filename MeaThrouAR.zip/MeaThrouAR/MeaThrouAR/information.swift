//
//  information.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 28/07/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
class information: UIViewController {

    @IBOutlet weak var lastMeasure: UILabel!
    @IBOutlet weak var descOfMeasure: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let user = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(user!).observeSingleEvent(of: .value, with: { snapshot in
            if let snap = snapshot.value as? [String : AnyObject]{
            if let lmeasure = snap["measureTwoPoint"] as? String{
                
                self.lastMeasure.text = lmeasure 
                
            }else{
                print("no")
            }
                if let Desc = snap["Description"] as? String{
                    
                    self.descOfMeasure.text = Desc
                    
                }else{
                    print("noDes")
                }
                
            }else{
                print("nooo")
            }
        })
        
        
        
       
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
