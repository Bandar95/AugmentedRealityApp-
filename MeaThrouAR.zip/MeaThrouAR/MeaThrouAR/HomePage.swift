//
//  HomePage.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 30/05/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth



class HomePage: UIViewController {

    @IBOutlet weak var loginBorder: UIButton!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var passLabel: UITextField!
   
    @IBOutlet weak var errorLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
            loginBorder.layer.cornerRadius = 10
        
        
        

        // Do any additional setup after loading the view.
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
    @IBAction func loginClicked(_ sender: UIButton) {
        
        Auth.auth().signIn(withEmail: self.emailLabel.text!, password: self.passLabel.text!) { (user, error) in
            if (error != nil){
                self.emailLabel.text = "Email or Password is not correct"
                print("errrrrrrrrrrrrrrrrr")
            }else {
                print("ssssssssssssssssssss")
                self.performSegue(withIdentifier: "segue1", sender: self)
                
            }
            
            
        }
        
    }
}
