//
//  PersistenceML.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 04/07/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import ARKit
import SceneKit
import Vision




class PersistenceML: UIViewController {

    @IBOutlet weak var wall: UIButton!
    @IBOutlet weak var area: UIButton!
    @IBOutlet weak var line: UIButton!
    @IBOutlet weak var prSave: UIButton!
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var sceneView: ARSCNView!
    @IBOutlet weak var Debug: UITextView!
    var wallButtonCenter : CGPoint!// to take the cube button center
    var areaBottunCenter : CGPoint!// to take the area button center
    var lineButtonCenter : CGPoint!
    
    
    
    let dispatchQueueML = DispatchQueue(label: "com.hw.dispatchqueueml") // A Serial Queue
    var visionRequests = [VNRequest]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        wallButtonCenter=wall.center
        areaBottunCenter=area.center
        lineButtonCenter=line.center
        wall.center = prSave.center
        area.center = prSave.center
        line.center=prSave.center
        //-------------------------------
        sceneView.delegate = self
        sceneView.showsStatistics = true
        configureLighting()
        addTapGestureToSceneView()
        
        // Create a new scene
        let scene = SCNScene() // SCNScene(named: "art.scnassets/ship.scn")!
        
        // Set the scene to the view
        sceneView.scene = scene
        
        // --- ML & VISION ---
        
        // Setup Vision Model
        guard let selectedModel = try? VNCoreMLModel(for: DetectHand().model) else {
            fatalError("Could not load model. Ensure model has been drag and dropped (copied) to XCode Project. Also ensure the model is part of a target (see: https://stackoverflow.com/questions/45884085/model-is-not-part-of-any-target-add-the-model-to-a-target-to-enable-generation ")
        }
        
        // Set up Vision-CoreML Request
        let classificationRequest = VNCoreMLRequest(model: selectedModel, completionHandler: classificationCompleteHandler)
        classificationRequest.imageCropAndScaleOption = VNImageCropAndScaleOption.centerCrop // Crop from centre of images and scale to appropriate size.
        visionRequests = [classificationRequest]
        
        loopCoreMLUpdate()
    }
    
    @IBAction func prSaveClicked(_ sender: UIButton) {
        if prSave.currentImage == UIImage (named: "save_on")! {
            UIView.animate(withDuration: 0.3, animations: {//the animation of buttons
                //to make buttons are visible
                self.wall.alpha=1
                self.area.alpha=1
                self.line.alpha=1
                // to open the menu
                self.wall.center = self.wallButtonCenter
                self.area.center = self.areaBottunCenter
                self.line.center = self.lineButtonCenter
            })
        }else {
            UIView.animate(withDuration: 0.3, animations: {
                self.wall.alpha=0
                self.area.alpha=0
                self.line.alpha=0
                
                self.wall.center = self.prSave.center
                self.area.center = self.prSave.center
                self.line.center = self.prSave.center
            })
            
        }
        tuggButton(button: sender, onImage:UIImage(named: "save_on")!, offImage: UIImage(named: "save_off")!)
        
    }
    func tuggButton(button : UIButton, onImage: UIImage, offImage: UIImage){
        if button.currentImage==offImage{
            button.setImage(onImage, for: .normal)
        }else{
            button.setImage(offImage, for: .normal)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        //  let configuration = ARWorldTrackingConfiguration()
        
        resetTrackingConfiguration()
        
        
        // Run the view's session
        //  sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    // MARK: - ARSCNViewDelegate
    
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            // Do any desired updates to SceneKit here.
        }
    }
    
    // MARK: - MACHINE LEARNING
    
    func loopCoreMLUpdate() {
        // Continuously run CoreML whenever it's ready. (Preventing 'hiccups' in Frame Rate)
        dispatchQueueML.async {
            // 1. Run Update.
            self.updateCoreML()
            // 2. Loop this function.
            self.loopCoreMLUpdate()
        }
    }
    
    func updateCoreML() {
        // Get Camera Image as RGB
        let pixbuff : CVPixelBuffer? = (sceneView.session.currentFrame?.capturedImage)
        if pixbuff == nil { return }
        let ciImage = CIImage(cvPixelBuffer: pixbuff!)
        
        // Prepare CoreML/Vision Request
        let imageRequestHandler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        // Run Vision Image Request
        do {
            try imageRequestHandler.perform(self.visionRequests)
        } catch {
            print(error)
        }
    }
    
    func classificationCompleteHandler(request: VNRequest, error: Error?) {
        // Catch Errors
        if error != nil {
            print("Error: " + (error?.localizedDescription)!)
            return
        }
        guard let observations = request.results else {
            print("No results")
            return
        }
        
        // Get Classifications
        let classifications = observations[0...1] // top 2 results
            .compactMap({ $0 as? VNClassificationObservation })
            .map({ "\($0.identifier) \(String(format:" : %.2f", $0.confidence))" })
            .joined(separator: "\n")
        
        // Render Classifications
        DispatchQueue.main.async {
            // Print Classifications
            // print(classifications)
            // print("-------------")
            
            // Display Debug Text on screen
            
            self.Debug.text = "TOP 2 PROBABILITIES: \n" + classifications
            
            // Display Top Symbol
            // var symbol = ""
            let topPrediction = classifications.components(separatedBy: "\n")[0]
            let topPredictionName = topPrediction.components(separatedBy: ":")[0].trimmingCharacters(in: .whitespaces)
            // Only display a prediction if confidence is above 1%
            let topPredictionScore:Float? = Float(topPrediction.components(separatedBy: ":")[1].trimmingCharacters(in: .whitespaces))
            if (topPredictionScore != nil && topPredictionScore! > 0.01) {
                
                if (topPredictionName == "NOHand") {
                    print("Nnhand")
                }
                
                if (topPredictionName == "OpenHand") {
                    print("TwoFingers")
                    self.Save()
                    
                }
            }
            
            //  self.textOverlay.text = symbol
            
        }
    }
    
    // MARK: - HIDE STATUS BAR
    override var prefersStatusBarHidden : Bool { return true }
    
    
    //   ----------------------------------------------------------------
    
    
    
    var worldMapURL: URL = {
        do {
            return try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                .appendingPathComponent("worldMapURL")
        } catch {
            fatalError("Error getting world map URL from document directory.")
        }
    }()
    
    
    
    
    
    func Save() {
        
        
        sceneView.session.getCurrentWorldMap { (worldMap, error) in
            guard let worldMap = worldMap else {
                return self.setLabel(text: "Error getting current world map.")
            }
            
            do {
                try self.archive(worldMap: worldMap)
                DispatchQueue.main.async {
                    self.setLabel(text: "World map is saved.")
                }
            } catch {
                fatalError("Error saving world map: \(error.localizedDescription)")
            }
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    /*
     @IBAction func Save(_ sender: UIBarButtonItem) {
     
     
     sceneView.session.getCurrentWorldMap { (worldMap, error) in
     guard let worldMap = worldMap else {
     return self.setLabel(text: "Error getting current world map.")
     }
     
     do {
     try self.archive(worldMap: worldMap)
     DispatchQueue.main.async {
     self.setLabel(text: "World map is saved.")
     }
     } catch {
     fatalError("Error saving world map: \(error.localizedDescription)")
     }
     }
     
     
     
     
     }
     
     */
    
    
    
    
    @available(iOS 12.0, *)
    @IBAction func Reset(_ sender: UIBarButtonItem) {
        resetTrackingConfiguration()
    }
    
    
    /*
     func Load() {
     
     guard let worldMapData = retrieveWorldMapData(from: worldMapURL),
     let worldMap = unarchive(worldMapData: worldMapData) else { return }
     resetTrackingConfiguration(with: worldMap)
     }
     
     */
    
    
    
    
    
    
    
    @IBAction func Load(_ sender: UIBarButtonItem) {
        
        guard let worldMapData = retrieveWorldMapData(from: worldMapURL),
            let worldMap = unarchive(worldMapData: worldMapData) else { return }
        resetTrackingConfiguration(with: worldMap)
    }
    
    
    
    func setLabel(text: String) {
        Label.text = text
    }
    
    
    
    
    
    @available(iOS 12.0, *)
    func resetTrackingConfiguration(with worldMap: ARWorldMap? = nil) {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        
        let options: ARSession.RunOptions = [.resetTracking, .removeExistingAnchors]
        if let worldMap = worldMap {
            configuration.initialWorldMap = worldMap
            setLabel(text: "Found saved world map.")
        } else {
            setLabel(text: "Move camera around to map your surrounding space.")
        }
        
        sceneView.debugOptions = [.showFeaturePoints]
        sceneView.session.run(configuration, options: options)
    }
    
    
    
    func addTapGestureToSceneView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didReceiveTapGesture(_:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func didReceiveTapGesture(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: sceneView)
        guard let hitTestResult = sceneView.hitTest(location, types: [.featurePoint, .estimatedHorizontalPlane]).first
            else { return }
        let anchor = ARAnchor(transform: hitTestResult.worldTransform)
        sceneView.session.add(anchor: anchor)
    }
    
    func generateSphereNode() -> SCNNode {
        let sphere = SCNSphere(radius: 0.01)
        let sphereNode = SCNNode()
        sphereNode.position.y += Float(sphere.radius)
        sphereNode.geometry = sphere
        return sphereNode
    }
    
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    
    func archive(worldMap: ARWorldMap) throws {
        let data = try NSKeyedArchiver.archivedData(withRootObject: worldMap, requiringSecureCoding: true)
        try data.write(to: self.worldMapURL, options: [.atomic])
    }
    
    func retrieveWorldMapData(from url: URL) -> Data? {
        do {
            return try Data(contentsOf: self.worldMapURL)
        } catch {
            self.setLabel(text: "Error retrieving world map data.")
            return nil
        }
    }
    
    func unarchive(worldMapData data: Data) -> ARWorldMap? {
        guard let unarchievedObject = try? NSKeyedUnarchiver.unarchivedObject(ofClass: ARWorldMap.self, from: data),
            let worldMap = unarchievedObject else { return nil }
        return worldMap
    }
    
    
}

@available(iOS 12.0, *)
extension PersistenceML: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard !(anchor is ARPlaneAnchor) else { return }
        let sphereNode = generateSphereNode()
        DispatchQueue.main.async {
            node.addChildNode(sphereNode)
        }
    }
    
}

extension float4x4 {
    var translations: float3 {
        let translations = self.columns.3
        return float3(translations.x, translations.y, translations.z)
    }
}

extension UIColor {
    open class var transparentWhites: UIColor {
        return UIColor.white.withAlphaComponent(0.70)
    }
}


    
    
 /*

    
    @IBAction func Reset(_ sender: Any) {
    }
    
    
    @IBAction func Load(_ sender: Any) {
    }
    
    */
    
    
    
    
    
    
    

