//
//  ViewController2.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 11/05/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit

class ViewController2: NSObject {

}
