//
//  ViewController.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 08/05/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet weak var prSave: UIButton!
    @IBOutlet weak var line: UIButton!// variable for line button
    @IBOutlet weak var wall: UIButton!// variable for cube button
    @IBOutlet weak var area: UIButton!// variable for area button
    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet weak var Label1: UILabel!
    var wallButtonCenter : CGPoint!// to take the cube button center
    var areaBottunCenter : CGPoint!// to take the area button center
    var saveButtonCenter : CGPoint!
    
    var nodes = [SCNNode]()
    
    override func viewDidLoad (){
    super.viewDidLoad()
        // identify the place of buttons
        wallButtonCenter=wall.center
        areaBottunCenter=area.center
        saveButtonCenter=prSave.center
        wall.center = line.center
        area.center = line.center
        prSave.center=line.center
        //---------------------
            sceneView.delegate = self
         //   sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        configureLighting()
      //  addTapGestureToSceneView()
        
        
    }
    
    
    
    
    // this function of click on the line button
    @IBAction func lineClicked(_ sender: UIButton) {
        
        if line.currentImage == UIImage (named: "ruler_on")! {
            UIView.animate(withDuration: 0.3, animations: {//the animation of buttons
                //to make buttons are visible
                self.wall.alpha=1
                self.area.alpha=1
                self.prSave.alpha=1
                // to open the menu
                self.wall.center = self.wallButtonCenter
                self.area.center = self.areaBottunCenter
                self.prSave.center = self.saveButtonCenter
            })
        }else {
            UIView.animate(withDuration: 0.3, animations: {
                self.wall.alpha=0
                self.area.alpha=0
                self.prSave.alpha=0
                
                self.wall.center = self.line.center
                self.area.center = self.line.center
                self.prSave.center = self.line.center
            })
            
        }
        tuggButton(button: sender, onImage:UIImage(named: "ruler_on")!, offImage: UIImage(named: "ruler_off")!)
        
    }//(Menue) to change the button
    func tuggButton(button : UIButton, onImage: UIImage, offImage: UIImage){
        if button.currentImage==offImage{
            button.setImage(onImage, for: .normal)
        }else{
            button.setImage(offImage, for: .normal)
        }
    }
    
    
    
    
    
    
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
     super.viewWillAppear(animated)
        resetTrackingConfiguration()

       
    
        // Create a session configuration
       // let configuration = ARWorldTrackingConfiguration()
     //   configuration.planeDetection = .horizontal
        
        // Run the view's session
       // sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    

    }
    
    
    
  /*
    func addTapGestureToSceneView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didReceiveTapGesture(_:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func didReceiveTapGesture(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: sceneView)
        guard let hitTestResult = sceneView.hitTest(location, types: [.featurePoint, .estimatedHorizontalPlane]).first
            else { return }
        let anchor = ARAnchor(transform: hitTestResult.worldTransform)
        sceneView.session.add(anchor: anchor)
    }
    
    */
    
    
    
    
    
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }

    
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      if nodes.count>=2{
            for node in nodes{
                node.removeFromParentNode()
            }
            nodes.removeAll()
        }
 
        if let touchLocation = touches.first?.location(in: sceneView){
            let hitTestResults = sceneView.hitTest(touchLocation, types: .featurePoint)
            
            if let hitresult = hitTestResults.first{
                addDotAt(hitresult:hitresult)
            }
        }
    }
 
    
    func addDotAt(hitresult:ARHitTestResult){
        
        let sphere = SCNSphere(radius: 0.01)
        let material = SCNMaterial()
        material.diffuse.contents = UIImage(named: "KAU.jpg")
        sphere.materials = [material]
        
        let dotNode = SCNNode()
        dotNode.geometry = sphere
        dotNode.position = SCNVector3(hitresult.worldTransform.columns.3.x,hitresult.worldTransform.columns.3.y,hitresult.worldTransform.columns.3.z)
        nodes.append(dotNode)
        sceneView.scene.rootNode.addChildNode(dotNode)
        
        
        if nodes.count >= 2 {
            caculateDistance()
            
        }
    }
 
        func caculateDistance(){
            
           let startNode = nodes[0]
           let endNode = nodes[1]
           print(startNode.position,endNode.position)
           let a = endNode.position.x - startNode.position.x
           let b = endNode.position.y - startNode.position.y
           let c = endNode.position.z - startNode.position.z
           let distance = sqrt(pow(a, 2) + pow(b, 2) + pow(c, 2))
          //print(distance)
            let dis : String
            dis = "\(distance*100)"
            addTextWith("\(distance * 100)", atPosition: endNode.position)
            
            let user = Auth.auth().currentUser?.uid
            Database.database().reference().child("users").child(user!).child("measureTwoPoint").setValue(dis)


            
    }
            
   // @IBAction func saveMeasure(_ sender: UIButton) {
    //}
    func addTextWith(_ text:String, atPosition position:SCNVector3){
        let textNode = SCNNode()
        let textGeometry = SCNText(string: text, extrusionDepth: 0.5)
        textGeometry.font = UIFont.systemFont(ofSize:4)
        textGeometry.firstMaterial?.diffuse.contents = UIColor.lightGray
        textNode.geometry = textGeometry
        textNode.scale = SCNVector3(0.01, 0.01, 0.01)
       textNode.position = SCNVector3(position.x, position.y + 0.01, position.z)
        // textNode.position = SCNVector3((position.x+position.x)/2.0, (position.y+position.y)/2.0 ,(position.z+position.z)/2.0)
        
       
        nodes.append(textNode)
        sceneView.scene.rootNode.addChildNode(textNode)
        
        
    }
    
    
    
    var worldMapURL: URL = {
        do {
            return try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                .appendingPathComponent("worldMapURL")
        } catch {
            fatalError("Error getting world map URL from document directory.")
        }
    }()
    
    
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    /*
    
    @IBAction func Save(_ sender: UIButton) {
       
        sceneView.session.getCurrentWorldMap { (worldMap, error) in
            guard let worldMap = worldMap else {
        //    return self.setLabel(text: "Error getting current world map.")
               
            }
            
            do {
                try self.archive(worldMap: worldMap)
                DispatchQueue.main.async {
            //     self.setLabel(text: "World map is saved.")
                    
                }
            } catch {
              fatalError("Error saving world map: \(error.localizedDescription)")
               
            }
        }
    }
 
 */
    
    
    
    func showInputDialog() {
        //Creating UIAlertController and
        //Setting title and message for the alert dialog
        let alertController = UIAlertController(title: "Description", message: "Add the descrioption to your measure", preferredStyle: .alert)
        
        //the confirm action taking the inputs
        let confirmAction = UIAlertAction(title: "Enter", style: .default) { (_) in
            
            //getting the input values from user
            let description = alertController.textFields?[0].text
            
            let user = Auth.auth().currentUser?.uid
            Database.database().reference().child("users").child(user!).child("Description").setValue(description)
            
            
        }
        
        //the cancel action doing nothing
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in }
        
        //adding textfields to our dialog box
        alertController.addTextField { (textField) in
            textField.placeholder = "Enter your description"
        }
        
        
        //adding the action to dialogbox
        alertController.addAction(confirmAction)
        alertController.addAction(cancelAction)
        
        //finally presenting the dialog box
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    @IBAction func Load(_ sender: UIButton) {
        
        guard let worldMapData = retrieveWorldMapData(from: worldMapURL),
            let worldMap = unarchive(worldMapData: worldMapData) else { return }
        resetTrackingConfiguration(with: worldMap)
    }
    
    
    
    
    @IBAction func Clear(_ sender: UIButton) {
        
        resetTrackingConfiguration()

    }
    
    
    
    
    func resetTrackingConfiguration(with worldMap: ARWorldMap? = nil) {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        
        let options: ARSession.RunOptions = [.resetTracking, .removeExistingAnchors]
        if let worldMap = worldMap {
            configuration.initialWorldMap = worldMap
     //     setLabel(text: "Found saved world map.")
            
        } else {
         //  setLabel(text: "Move camera around to map your surrounding space.")
            
        }
        
        sceneView.debugOptions = [.showFeaturePoints]
        sceneView.session.run(configuration, options: options)
    }
    
    
    
    func archive(worldMap: ARWorldMap) throws {
        let data = try NSKeyedArchiver.archivedData(withRootObject: worldMap, requiringSecureCoding: true)
        try data.write(to: self.worldMapURL, options: [.atomic])
    }
    
    
    
    func retrieveWorldMapData(from url: URL) -> Data? {
        do {
            return try Data(contentsOf: self.worldMapURL)
        } catch {
       //    self.setLabel(text: "Error retrieving world map data.")
            
            return nil
        }
    }
    
    
    func unarchive(worldMapData data: Data) -> ARWorldMap? {
        guard let unarchievedObject = try? NSKeyedUnarchiver.unarchivedObject(ofClass: ARWorldMap.self, from: data),
            let worldMap = unarchievedObject else { return nil }
        return worldMap
    }
    
    /*
    func setLabel(text: String) {
        Label1.text = text
    }
    */
    
    
    func generateSphereNode() -> SCNNode {
        let sphere = SCNSphere(radius: 0.02)
        let material = SCNMaterial()
        material.diffuse.contents = UIImage(named: "KAU.jpg")
        sphere.materials = [material]
        
        
        
        let sphereNode = SCNNode()
        sphereNode.position.y += Float(sphere.radius)
        sphereNode.geometry = sphere
        return sphereNode
    }
    
  
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard !(anchor is ARPlaneAnchor) else { return }
        let sphereNode = generateSphereNode()
        DispatchQueue.main.async {
            node.addChildNode(sphereNode)
        }
    }
    
    @IBAction func saveMeasure(_ sender: UIButton) {
         showInputDialog()
    }
}
    
    


extension float4x4 {
    var translation: float3 {
        let translation = self.columns.3
        return float3(translation.x, translation.y, translation.z)
    }
}

extension UIColor {
    open class var transparentWhite: UIColor {
        return UIColor.white.withAlphaComponent(0.70)
    }
}


 
  


    
    
    
    
