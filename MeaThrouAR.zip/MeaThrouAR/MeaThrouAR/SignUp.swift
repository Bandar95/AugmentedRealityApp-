//
//  SignUp.swift
//  MeaThrouAR
//
//  Created by تركي الاحمدي on 26/06/1440 AH.
//  Copyright © 1440 turki-12457@hotmail.com. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class SignUp: UIViewController {
   @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var fNameLabel: UITextField!
    @IBOutlet weak var lNameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    
    @IBOutlet weak var signUpBorder: UIButton!
    @IBOutlet weak var passLabel: UITextField!
    @IBOutlet weak var conPassLabel: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        signUpBorder.layer.cornerRadius = 10

       
    }
    
    @IBAction func SignUp(_ sender: UIButton) {
        if (passLabel.text == conPassLabel.text){
            Auth.auth().createUser(withEmail: emailLabel.text!, password: passLabel.text!) { (user, error) in
                if (error != nil){
                    self.errorLabel.text = "Email or Password is not correct"
                    print(error.debugDescription)
                }else {
                    let user = Auth.auth().currentUser?.uid
                    Database.database().reference().child("users").child(user!).child("firstName").setValue(self.fNameLabel.text)
                    Database.database().reference().child("users").child(user!).child("lastName").setValue(self.lNameLabel.text)
                    Database.database().reference().child("users").child(user!).child("email").setValue(self.emailLabel.text)
                    Database.database().reference().child("users").child(user!).child("password").setValue(self.passLabel.text)
                    
                    print("Registratin Successful!")
                    self.performSegue(withIdentifier: "segue2", sender: self)
                    
                }
            }
        }else{
            errorLabel.text = "The password isn't the same"
        }
        
            
    }
    
    

}
