//
//  ViewController2.swift
//  MeaThrouAR
//
//  Created by Bandar Alahmadi & Faisal Alghamdi on 11/05/1440 AH.
//  Copyright © 1440 byalahmadi@outlook.sa All rights reserved.
//

import UIKit
import SceneKit
import ARKit


class space: UIViewController, ARSCNViewDelegate {
    @IBOutlet var sceneView: ARSCNView!
    
    @IBOutlet weak var prSave: UIButton!
    @IBOutlet weak var wall: UIButton!
    @IBOutlet weak var area: UIButton!
    @IBOutlet weak var line: UIButton!
    var wallButtonCenter : CGPoint!// to take the cube button center
    var lineBottunCenter : CGPoint!// to take the area button center
    var saveButtonCenter : CGPoint!
    var grids = [Grid]()
    
    override func viewDidLoad (){
        
        super.viewDidLoad()
        
        wallButtonCenter=wall.center
        lineBottunCenter=line.center
        saveButtonCenter=prSave.center
        wall.center = area.center
        line.center = area.center
        prSave.center = area.center
        sceneView.delegate = self
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
    }
    
    @IBAction func areaClicked(_ sender: UIButton) {
        if area.currentImage == UIImage (named: "area_on")! {
            UIView.animate(withDuration: 0.3, animations: {//the animation of buttons
                //to make buttons are visible
                self.wall.alpha=1
                self.line.alpha=1
                self.prSave.alpha=1
                // to open the menu
                self.wall.center = self.wallButtonCenter
                self.line.center = self.lineBottunCenter
                self.prSave.center = self.saveButtonCenter
            })
        }else {
            UIView.animate(withDuration: 0.3, animations: {
                self.wall.alpha=0
                self.line.alpha=0
                self.prSave.alpha=0
                
                self.wall.center = self.area.center
                self.line.center = self.area.center
                self.prSave.center=self.area.center
            })
            
        }
        tuggButton(button: sender, onImage:UIImage(named: "area_on")!, offImage: UIImage(named: "area_off")!)
        
    }
    
    func tuggButton(button : UIButton, onImage: UIImage, offImage: UIImage){
        if button.currentImage==offImage{
            button.setImage(onImage, for: .normal)
        }else{
            button.setImage(offImage, for: .normal)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    // 1.
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        let grid = Grid(anchor: anchor as! ARPlaneAnchor)
        self.grids.append(grid)
        node.addChildNode(grid)
    }
    // 2.
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        let grid = self.grids.filter { grid in
            return grid.anchor.identifier == anchor.identifier
            }.first
        
        guard let foundGrid = grid else {
            return
        }
        
        foundGrid.update(anchor: anchor as! ARPlaneAnchor)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
